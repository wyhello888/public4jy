/**
 * Created by tydte on 2017/7/18.
 */
var http=require("http");
var fs=require("fs");
var url=require("url");
var querystring=require("querystring");
var server=http.createServer(function(req,res){
    var obj=querystring.parse("name=12&a=13");
    console.log(obj.a);
    res.end();

});
server.listen(80,"172.18.14.26");
