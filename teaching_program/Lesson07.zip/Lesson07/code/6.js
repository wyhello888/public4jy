/**
 * Created by tydte on 2017/7/18.
 */
var http=require("http");
var fs=require("fs");
var url=require("url");
var server=http.createServer(function(req,res){
    res.writeHead(200,{"Content-type":"text/html;charset=UTF-8"});
    /******************异步*******************/
    //fs.readFile("./aaaaaa.txt",function(err,data){
    //    console.log(data.toString());
    //    res.end();
    //});
    console.log("真的吗？");
    /********************同步*********************/
    var data=fs.readFileSync("./aaaaaa.txt");
    console.log(data.toString());
    res.end();

});
server.listen(80,"172.18.14.26");
