/**
 * Created by tydte on 2017/7/18.
 */
var http=require("http");
var fs=require("fs");
var url=require("url");
var server=http.createServer(function(req,res){
    var obj=url.parse(req.url,true).query;
   fs.writeFile("bbbb.txt",obj.str,{flag:"a"},function(err){
       console.log("成功")
   })

});
server.listen(80,"172.18.14.26");
