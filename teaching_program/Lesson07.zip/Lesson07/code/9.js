/**
 * Created by tydte on 2017/7/19.
 */
var fs=require("fs");
fs,mkdir("./",function(){

})