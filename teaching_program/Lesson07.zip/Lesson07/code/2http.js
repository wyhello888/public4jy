var http=require("http");
var server=http.createServer(function(req,res){
    res.writeHead(200,{"Content-type":"text/plain;charset=UTF-8"});
    res.end("<h1>我今天好高兴！我今天你们考的真不错，老师很欣慰</h1>");
});
server.listen(80);