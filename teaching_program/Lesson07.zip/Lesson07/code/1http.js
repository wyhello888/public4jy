/**
 * Created by tydte on 2017/7/18.
 */
//console.log(12);
//function test(){
//    console.log(12);
//}
//test();
//require是将指定的包引入过来，也就是给自己增加了某些特殊功能。
var http=require("http");
var fs=require("fs");//新包
//创建一个服务器 createServer方法。方法里面传递一个回调函数。
//request请求，response响应，回应
var server=http.createServer(function(request,response){
    response.writeHead(200,{"Content-type":"text/html;charset=UTF-8"});
    //var date=new Date();//
    var ran=Math.floor(Math.random()*899999+100000);
    console.log("王椿喜的期望薪资是："+ran);
    fs.readFile("./1.js.html",function(err,data){
        response.write(data);
        //console.log(data);
       // response.write(data);
       // response.write(data);
       // var nowTime=new Date();
       // console.log((nowTime-date)+"毫秒");
        console.log("王椿喜的薪资达到了");
        response.end("不行，我还没想好!");//我要做出回应。说明响应结束了。
    })
    //console.log("还有谁！");

});
server.listen(80,"172.18.14.26");