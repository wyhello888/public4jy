/**
 * Created by tydte on 2017/7/18.
 */
var http=require("http");
var fs=require("fs");
var server=http.createServer(function(req,res){
    if(req.url=="/favicon.ico")
        return;
    if(req.url=="/88.html"){
        fs.readFile("./22.html",function(err,data){
            if(err)
                console.log(err);
            else{
                console.log(req.url);
                res.write(data);
                res.end();
            }
        })
    }else if(req.url=="/2.html"){
        fs.readFile("./2.html",function(err,data){
            if(err)
                console.log(err);
            else{
                console.log(req.url);
                res.write(data);
                res.end();
            }
        })
    }else if(req.url=="/2.css"){
        fs.readFile("./2.css",function(err,data){
            res.writeHead(200,{"Content-type":"text/css;charset=UTF-8"});
            if(err)
                console.log(err);
            else{
                console.log(req.url);
                res.write(data);
                res.end();
            }
        })
    }
    else{
        res.writeHead(404,{"Content-type":"text/html;charset=UTF-8"});
        res.end("哈哈，找不到了吧，我藏起来了！");
    }


});
server.listen(80);
