/**
 * Created by tydte on 2017/7/18.
 */
var http=require("http");
var fs=require("fs");
var server=http.createServer(function(req,res){
    console.log(req.url);
    if(req.url=="/a.html"){
        res.writeHead(200,{"Content-type":"text/html;charset=UTF-8"});
        res.end("我想换一部iphone"+(1+2+3+2)+"s");//结束请求
    }else if(req.url=="/b.html"){
        fs.readFile("./22.html",function(err,data){
            res.write(data);
            res.end();
        })
    }else if(req.url=="/c.html"){
        fs.readFile("./2.html",function(err,data){
            res.write(data);
            res.end();
        })
    }else if(req.url=="/22.css"){
        res.writeHead(200,{"Content-type":"text/css;charset=UTF-8"});
        fs.readFile("./2.css",function(err,data){
            res.write(data);
            res.end();
        })
    }
    else{
        res.writeHead(404,{"Content-type":"text/html;charset=UTF-8"});
        res.end("404错误");
    }

});
server.listen(80,"172.18.14.26");
