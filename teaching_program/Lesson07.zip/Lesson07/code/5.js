/**
 * Created by tydte on 2017/7/18.
 */
var http=require("http");
var fs=require("fs");
var url=require("url");
var server=http.createServer(function(req,res){
    res.writeHead(200,{"Content-type":"text/html;charset=UTF-8"});
    res.write("req.url------"+req.url+"<br>");
    res.write("pathname-----"+url.parse(req.url).pathname+"<br>");
    res.write("query--------"+url.parse(req.url).query+"<br>");
    var obj=url.parse(req.url,true).query;//将我得到的字符串转换成了对象。
    for(var i in obj){
        res.write("queryOBJ--------"+i+":"+obj[i]+"<br>");
    }

    res.end();
});
server.listen(80,"172.18.14.26");
