/**
 * Created by tydte on 2017/7/22.
 */
var mongodb=require("mongodb");
var MongoClient=mongodb.MongoClient;
//_就说明是模块的一个内部的方法,callbackl 回调函数
function _connect(callback){
    var url="mongodb://127.0.0.1:27017/weibo";
    MongoClient.connect(url,function(err,db){
        callback(err,db);
        db.close();
    })
}
//查找的封装咱们先到这，一回再回来。
//pageObj是一个对象，如果传该对象就认为是要做分页，不传就是正常查找
//pageObj有三个属性分别是sort,skip,limit
//{sort:{name:1},skip:0,limit:0}
exports.find=function(collectionName,json,callback,pageObj){
    //sort排序  {}
    //   skip   0
    // limit    0
    var sort={};
    var skip=0;
    var limit=0;
    if(arguments.length==4){
        sort=pageObj.sort?pageObj.sort:{};
        skip=pageObj.skip?pageObj.skip:0;
        limit=pageObj.limit?pageObj.limit:0;
    }
    _connect(function(err,db){
        db.collection(collectionName).find(json).sort(sort).skip(skip).limit(limit).toArray(function(err,results){
            callback(err,results);
        })
    })
};
exports.count=function(collectionName,json,callback){
    _connect(function(err,db){
        //callback(db.collection(collectionName).find(json).count());
        db.collection(collectionName).count(json).then(function(count){
            callback(count);
        })
    })
};
//collectionName是指的集合，json添加的内容，callback回调的函数
exports.insert=function(collectionName,json,callback){
    _connect(function(err,db){
        db.collection(collectionName).insertOne(json,function(err,results){
            callback(err,results);
        })
    })
}
//删除 json指的是删除条件
exports.delete=function(collectionName,json,callback){
    _connect(function(err,db){
        db.collection(collectionName).deleteOne(json,function(err,results){
            callback(err,results);
        })
    })
}
//修改 jsonT修改条件，jsonN内容
exports.update=function(collectionName,jsonT,jsonN,callback){
    _connect(function(err,db){
        db.collection(collectionName).updateOne(jsonT,jsonN,function(err,results){
            callback(err,results);
        })
    })
};
//获得一条记录
exports.findOne=function(collectionName,json,callback){
    _connect(function(err,db){
        db.collection(collectionName).findOne(json,function(err,results){
            callback(err,results);
        })
    })
}





