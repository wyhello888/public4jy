/**
 * Created by tydte on 2017/7/31.
 */
console.log(Math.floor(10/3));