/**
 * Created by tydte on 2017/7/31.
 */
var express=require("express");
var mongodb=require("mongodb");
var db=require("./model/db.js");
var app=express();
app.use(express.static("./public"));

//添加的接口
app.get("/addComment",function(req,res){
    db.insert("comment",{//添加
        content:req.query.content,
        time:new Date().getTime(),
        top:0,
        down:0
    },function(err,results){
        if(err)
            res.json(-1);
        else{//说明已经成功啦
           getComment(1,function(err,results){
               if(err)
                   res.json(-2);
               else
                   res.json(results);
           })

        }
    })
});
//删除
app.get("/deletComment",function(req,res){
    db.delete("comment",{_id:mongodb.ObjectID(req.query.id)},function(err,results){
        //将当前最新的页面信息返回
        getComment(req.query.pageNum,function(err,results){
            if(err)
                res.json(-1);
            else
                res.json(results);
        })
    })
})
//顶或踩
app.get("/topOrDown",function(req,res){
    var obj={
        top:0,
        down:0
    };
    if(req.query.type==1){//顶
        obj.top=1;
    }else if(req.query.type==2){//踩
        obj.down=1;
    }else{
        res.json(-3);//传值有毛病
        return;
    }
     console.log(4);

    var info=db.findOne("comment",{_id:mongodb.ObjectID(req.query.id)},function(err,results){
        db.update("comment",{_id:mongodb.ObjectID(req.query.id)},{
            $set:{
                top:results.top+obj.top,
                down:results.down+obj.down
            }
        },function(err,results){
            if(err)
                res.json(-1);
            else{
                //将当前最新的页面信息返回
                getComment(req.query.pageNum,function(err,results){
                    if(err)
                        res.json(-1);
                    else
                        res.json(results);
                })
            }
        })
    })


})
//获得评论
app.get("/getComment",function(req,res){
    getComment(req.query.pageNum,function(err,results){
        if(err)
            res.json(-1);
        else
            res.json(results);
    })

});
function getComment(pageNum,fn){
    db.find("comment",{},function(err,results){
        getPageInfo(pageNum,function(pageObj){
            var obj={};
            obj.pageInfo=pageObj;
            obj.contentInfo=results;
            fn(err,obj);
        });
    },{
        sort:{time:-1},
        skip:(pageNum-1)*6,
        limit:6
    })
}
//获得分页
function getPageInfo(pageNum,fn){
    db.count("comment",{},function(count){
        var arr=[];
        var pageSum=Math.ceil(count/6);
        for(var i=1;i<=pageSum;i++){
            arr.push({
                pageNum:i,
                pageClass:pageNum==i?"active":""
            })
        }
        fn(arr);
    })
}
//=[{
//    pageNum:1,
//    pageClass:""
//},{
//    pageNum:2,
//    pageClass:""
//},{
//    pageNum:3,
//    pageClass:"active"
//},{
//    pageNum:4,
//    pageClass:""
//}]
//支持跨域的接口
app.get("/sum",function(req,res){

    res.send(req.query.callback+"("+ (parseInt(req.query.a)+parseInt(req.query.b))+")");
})

//app.get("/sum",function(req,res){
//    //res.send((parseInt(req.query.a)+parseInt(req.query.b)).toString());
//    res.json(parseInt(req.query.a)+parseInt(req.query.b));
//});
app.listen(80);