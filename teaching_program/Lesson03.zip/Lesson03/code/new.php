<?php
    echo "fn(".($_GET["num"]+1).");";
?>