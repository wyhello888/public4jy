<?php
    echo $_GET["voteNum"]+1;
?>