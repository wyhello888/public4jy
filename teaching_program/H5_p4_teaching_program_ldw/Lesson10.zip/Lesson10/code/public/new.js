/**
 * Created by tydte on 2017/7/21.
 */
var express=require("express");
var app=express();
var num=0;
//从数据库里面得到的内容
var newList=[{
    title:"我是新闻一"
},{
    title:"我是新闻二"
}
,{
       title:"我是新闻三"},{
        title:"我是新闻四"
    },{
        title:"我是新闻五"
    }];
app.get("/new/:id",function(req,res){
    res.send(newList[(req.params["id"]-1)]);
});
app.listen(80);