<?php
   // echo Date("Y-m-d H:i:s");
   if($_POST["name"]=="laowang"){
        echo "我爱你中国".$_POST["age"];
   }else{
        echo "嘿哟嘿哟嘿哟嘿";
   }
?>