/**
 * Created by tydte on 2017/7/11.
 */
//1、将公有的变量当作对象的属性
//2、将公有的函数当作对象的方法
function Tab(obj){
    this.myInput=document.querySelectorAll(obj.myInput);
    this.myDiv=document.querySelectorAll(obj.myDiv);
    this.colorArr=obj.colorArr;
    //this.init(obj);
}
Tab.prototype.init=function(obj){
    this.myInput[obj.index].style.background=this.colorArr[obj.index];
    this.myDiv[obj.index].style.display="block";
    var _this=this;
    for(var i=0;i<this.myInput.length;i++){
        this.myDiv[i].style.background=this.colorArr[i];
        this.myInput[i].onclick=(function(num){//添加事件
            return function(){
                console.log(this);
                this.style.background=_this.colorArr[num];
                for(var j=0;j<_this.myInput.length;j++){
                    if(j !=num){
                        _this.myInput[j].style.background=null;
                        _this.myDiv[j].style.display="none";

                    }else{
                        this.style.background=_this.colorArr[num];
                        _this.myDiv[j].style.display="block";
                    }
                }
            }
        })(i);
    }
}
