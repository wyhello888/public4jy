/**
 * Created by tydte on 2017/7/19.
 */
var http=require("http");
var ejs=require("ejs");
var fs=require("fs");
var server=http.createServer(function(req,res){
    if(req.url=="/favicon.ico")
        return;
    res.writeHead(200,{"Content-type":"text/html;charset=UTF-8"});
    fs.readFile("./view/index.ejs",function(err,data){
        var obj={
            name:"马可波罗",
            list:[
                "北京","上海","广州","深圳"
            ],
            article:[
                {
                    href:"http://www.baidu.com",
                    name:"百度"
                },{
                    href:"http://www.qiutong.com",
                    name:"邱彤"
                },{
                    href:"http://www.99.com",
                    name:"九块九包邮"
                }
            ]
        }
        res.write(ejs.render(data.toString(),obj));
        res.end();
    })

});
server.listen(80);
