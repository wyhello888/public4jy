/**
 * Created by tydte on 2017/7/19.
 */
var http=require("http");
var ejs=require("ejs");
var server=http.createServer(function(req,res){
    if(req.url=="/favicon.ico")
        return;
    res.writeHead(200,{"Content-type":"text/html;charset=UTF-8"});
    var string="我今天很开心，因为天气不错，挺风和日丽的<%=a%>";
    var str=ejs.render(string,{
        a:"我很好，勿挂念"
    });
    res.write(str);
    res.end();
});
server.listen(80);
