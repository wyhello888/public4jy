/**
 * Created by tydte on 2017/7/19.
 */
var http=require("http");
var url=require("url");
var querystring=require("querystring");
var fs=require("fs");
var server=http.createServer(function(req,res){
    if(req.url=="/favicon.ico")
        return;

    //console.log(req.tamade);
    //var str=tamade.parse(req.tamade).query;
    ////console.log(tamade.parse(req.tamade,true).query);
    //console.log(querystring.parse(str));
    //console.log(querystring.parse(str).name);
    if(req.url=="/1.html"){
        res.writeHead(200,{"Content-type":"text/html;charset=UTF-8"});
        fs.readFile("./1.html",function(err,data){
            res.write(data.toString());
            res.end("12");
        })
    }else{
        res.writeHead(404,{"Content-type":"text/html;charset=UTF-8"});
        res.end("找不到页面了吧，又错了吧！");
    }


});
server.listen(80);