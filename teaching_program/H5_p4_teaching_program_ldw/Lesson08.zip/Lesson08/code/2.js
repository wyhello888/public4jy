/**
 * Created by tydte on 2017/7/19.
 */
var m1=require("./test/2module.js");
//m1.fn();
//m1.obj.test();
//m1.obj.name;
m1.fn();

