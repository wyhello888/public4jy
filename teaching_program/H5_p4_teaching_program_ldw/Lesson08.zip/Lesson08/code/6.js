/**
 * Created by tydte on 2017/7/19.
 */
var m6=require("niuGulp");
m6.fn();