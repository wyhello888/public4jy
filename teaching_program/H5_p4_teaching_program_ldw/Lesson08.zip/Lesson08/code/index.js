/**
 * Created by tydte on 2017/7/19.
 */
var niuGulp=require("niuGulp");
var url=require("tamade");

niuGulp.openServer(3030,url.test);
