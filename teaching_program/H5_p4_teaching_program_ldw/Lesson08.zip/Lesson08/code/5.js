/**
 * Created by tydte on 2017/7/19.
 */
var m5=require("niuGulp");
m5.fn(33333);