/**
 * Created by tydte on 2017/7/19.
 */
function Box(name){
    this.name=name;
}
Box.prototype.run="奔跑吧，姐妹！"
function Desk(age,name){
    this.age=age;
    Box.call(this,name);
}
Desk.prototype=new Box();
var desk=new Desk(13,"laotie");
console.log(desk.name);
console.log(desk.run);