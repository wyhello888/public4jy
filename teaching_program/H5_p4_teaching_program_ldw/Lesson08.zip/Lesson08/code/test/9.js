/**
 * Created by tydte on 2017/7/19.
 */
var m9=require("niuGulp");
m9.m7();