/**
 * Created by tydte on 2017/7/19.
 */
function Box(name,age){
    this.name=name;
    this.age=age;
}
Box.prototype.fn=function(){
    console.log(this.name+this.age);
}
module.exports.Obj=Box;