/**
 * Created by tydte on 2017/7/19.
 */
/*************************继承**************
 * 原型链继承无法给父类传值**************/
//父类
function Box(name){
    this.name=name;
}
Box.prototype.age=88;
//子类
function Desk(blood){
    this.blood=blood;
}
Desk.prototype=new Box("12");

var desk=new Desk(1000);
console.log(desk.blood);
console.log(desk.name);
var desk1=new Desk(10000);


//function test(){
//    console.log(12);
//}
//console.log(test());