/**
 * Created by tydte on 2017/7/19.
 */
//function test(){
//    console.log(12);
//}
//var a=12;
//var name=13;
//function box(num1,num2){
//    return num1*num2;
//}
//var obj={
//    test:function(){
//        console.log(13);
//    },
//    name:"wla"
//}
//exports.obj=obj;
//exports.fn=test;
//exports.a=a;
//exports.name=13;
//exports.box=box;



exports.fn=function(){
    console.log(13);
}
