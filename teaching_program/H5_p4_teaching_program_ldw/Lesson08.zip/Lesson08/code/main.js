/**
 * Created by tydte on 2017/7/19.
 */
exports.openServer=function(){
    var http=require("http");
    var server=http.createServer(function(req,res){
        res.writeHead(200,{"Content-type":"text/html;charset=UTF-8"});
        res.end("500");
    });
    server.listen(80);
}


