/**
 * Created by tydte on 2017/7/19.
 */
var m4=require("4module.js");
console.log(m4.fn(3,4));