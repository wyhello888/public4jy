/**
 * Created by tydte on 2017/7/19.
 */
var http=require("http");
var querystring=require("querystring");
var fs=require("fs");
var server=http.createServer(function(req,res){
    if(req.url=="/favicon.ico")
        return;
    res.writeHead(200,{"Content-type":"text/html;charset=UTF-8"});
    if(req.url=="/" && req.method.toLowerCase()=="post"){
        var chunkData="";
        req.addListener("data",function(chunk){
            chunkData+=chunk;
        });
        req.addListener("end",function(){
            console.log(querystring.parse(chunkData));
            var obj=querystring.parse(chunkData);
            var str="_____________________________\n";
            for(var i in obj){
                str+=i+":"+obj[i]+"\n";
            }
            fs.writeFile("./info.txt",str,{flag:"a"},function(err){
                if(err)
                    console.log(err);
            })

        })
    }
    res.end(req.method);
});


server.listen(80);
