/**
 * Created by tydte on 2017/7/19.
 */
var m3=require("./test/3module.js");
var obj=new m3.Obj("wangdachui",18);
console.log(obj.name);
