/**
 * Created by tydte on 2017/7/13.
 */
;(function(window){
    var a=12;
    window.ajax=function(){
        return a;
    }

})(window);