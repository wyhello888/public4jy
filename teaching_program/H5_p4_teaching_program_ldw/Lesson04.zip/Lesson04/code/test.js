/**
 * Created by tydte on 2017/7/13.
 */
var obj={
    item:[
        {
            id:"123"
        },
        {
            id:"456"
        },
        {
            id:"789"
        }
    ],
    artice:{
        "123":{
            title:"我去火车站，打酱油",
            url:"http://www.baidu.com"
        },
        "456":{
            title:"我也去火车站，打酱油",
            url:"http://www.alibaba.com"
        },
        "789":{
            title:"我不去火车站，打酱油",
            url:"http://www.qq.com"
        }
    }

}