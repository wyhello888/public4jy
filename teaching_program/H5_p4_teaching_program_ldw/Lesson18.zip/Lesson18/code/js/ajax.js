/**
 * Created by tydte on 2017/6/21.
 */
function ajax(obj){
    var xhr=createXHR();//获得对象
    //开始传递参数了 http://www.baidu.com?
    obj.url+=obj.url.indexOf("?")>-1?"&":"?";
    obj.url+="ram="+Math.random();
    obj.data=parame(obj.data);
    if(obj.async==undefined){//如果没有传递是否异步，默认异步（true)
        obj.async=true;
    }
    if(obj.method=="get"){
        obj.url+="&"+obj.data;
    }
    if(obj.async){//如果是异步，我就添加该事件
        xhr.onreadystatechange=function(){//异步
            if(xhr.readyState==4){//值为4代表数据完全接收了
                callBack();
            }
        }
    }
    xhr.open(obj.method,obj.url,obj.async);//预备发送请求，
    if(obj.method=="post"){
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.send(obj.data);
    }else{
        xhr.send(null);//开始发送请求
    }

    if(!obj.async){//如果为同步
        callBack();
    }

    function parame(obj){//将对象转换为url格式
        if(obj !=undefined){
            var arr=[];
            for(var i in obj){
                arr.push(i+"="+obj[i]);
            }
            return  arr.join("&");
        }
        return null;

    }
    function callBack(){
        if(xhr.status==200){//成功
            obj.success(xhr.responseText);
        }else{//出错的提示
            alert("网错连接错误！！！错误代码为："+xhr.status+"错误的内容："+xhr.statusText);
        }
    }

    function createXHR(){//创建对象 实现对IE6的兼容 该方法是AJAX的一个子方法
        if(typeof XMLHttpRequest =="undefined")
            return new ActiveXObject("MSXML2.XMLHttp");
        return new XMLHttpRequest();
    }
}
