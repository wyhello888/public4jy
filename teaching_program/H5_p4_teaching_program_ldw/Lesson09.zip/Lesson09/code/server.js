/**
 * Created by tydte on 2017/7/20.
 */
var express=require("express");
var app=express();
////接收
//app.post("/user",function(req,res){
//    res.send("你POST过来吧");
//})
////接收以GET形式过来的数据
//app.get("/user",function(req,res){
//    //send只能出现一次
//    res.send("看看有没有东西啊");
//});
//all不管你是get还是POST我都会来者不俱
//app.all("/user",function(req,res){
//    res.send("我是你的全部");
//});
//路径不区分大小写
/********************有没有顺序*************************/
app.get("/user",function(req,res,next){
    //send只能出现一次
    console.log(1);
    //res.send("1");
    next();
});
app.get("/user",function(req,res){
    //send只能出现一次
    res.send("2");
});
app.get("/note/test/2323",function(req,res){
    res.send("12");
})
app.get("/note/:id/:score",function(req,res){
    res.send(req.params["id"]+"分数："+req.params["score"]);
})

//app.get("/note",function(req,res){
//    res.send("有个地方需要注意，就是通过？传递过来的参数或者有#都视而不见");
//})

app.listen(80);