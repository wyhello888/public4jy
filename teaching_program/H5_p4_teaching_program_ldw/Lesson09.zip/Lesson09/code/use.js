/**
 * Created by tydte on 2017/7/20.
 */
var express=require("express");
var app=express();
app.use(express.static("./public"));
//app.use("/",function(req,res){
//    //res.writeHead("")
//    res.write(req.originalUrl + "\n");   //    /admin/aa/bb/cc/dd
//    res.write(req.baseUrl + "\n");  //   /admin
//    res.write(req.path + "\n");   //    /aa/bb/cc/dd
//    res.end("你好");
//
//    //res.send("administrator");
//});
//app.use(function(req,res){
//    //res.writeHead("")
//    res.write(req.originalUrl + "\n");   //    /admin/aa/bb/cc/dd
//    res.write(req.baseUrl + "\n");  //   /admin
//    res.write(req.path + "\n");   //    /aa/bb/cc/dd
//    res.end("123");
//
//    //res.send("administrator");
//});

app.use(express.static("./public/dist"));

//app.get("/user",function(req,res){
//    console.log(req.query);
//    res.send(req.query.name);
//})
app.listen(80);