/**
 * Created by tydte on 2017/7/20.
 */
var express=require("express");
var app=express();
app.set("views","test");//将默认的文件夹views改成test
//设置视图引擎
app.set("view engine","ejs");
app.get("/user",function(req,res ){
    res.render("haha",{
        "name":"不知道起啥了，你就叫牛二吧"
    });
});
app.listen(80);