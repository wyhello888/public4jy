/**
 * Created by tydte on 2017/7/22.
 */
var express=require("express");
var mongodb=require("mongodb");
var MongoClient=mongodb.MongoClient;
var app=express();
app.get("/",function(req,res){
    var url="mongodb://127.0.0.1:27017/company";
    MongoClient.connect(url,function(err,db){
        if(err){
            console.log("连接数据库失败");
            return;
        }
        db.collection("worker").updateMany({"name":"李东方1"},{$set:{"name":"东方100"}},function(err,results){
            if(err){
                console.log("更新数据失败");
                return;
            }
            console.log("更新数据成功");

        })
        /**************************更改了一个******************************/
        //db.collection("worker").updateOne({"name":"李东方1"},{$set:{"name":"东方88"}},function(err,results){
        //    if(err){
        //        console.log("更新数据失败");
        //        return;
        //    }
        //    console.log("更新数据成功");
        //
        //})
        /*******************完全替换**************************/
        //db.collection("worker").updateOne({"name":"李东方1"},{"name":"李东方18"},function(err,results){
        //    if(err){
        //        console.log("更新数据失败");
        //        return;
        //    }
        //    console.log("更新数据成功");
        //
        //})
    })
    res.send("欢迎来到英雄联盟！");//"5972c165c46f5d25cc6e5b9c
});
app.listen(80);