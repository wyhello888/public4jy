/**
 * Created by tydte on 2017/7/22.
 */
var express=require("express");
var mongodb=require("mongodb");
var MongoClient=mongodb.MongoClient;
var app=express();
app.get("/",function(req,res){
    var url="mongodb://127.0.0.1:27017/company";
    MongoClient.connect(url,function(err,db){
        if(err){
            console.log("连接数据库失败");
            return;
        }
        db.collection("worker").deleteOne({"name":"李东方2"},function(err,results){
            if(err){
                console.log("删除数据失败");
                return;
            }
            console.log("删除数据成功");

        })
    })
    res.send("欢迎来到英雄联盟！");//"5972c165c46f5d25cc6e5b9c
});
app.listen(80);