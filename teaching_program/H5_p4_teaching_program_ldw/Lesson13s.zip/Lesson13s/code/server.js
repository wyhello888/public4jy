/**
 * Created by tydte on 2017/7/22.
 */
var express =require("express");
var mongodb=require("mongodb");
var bodyParser=require("body-parser");
var db=require("./model/db.js");
var app=express();
app.set("view engine","ejs");
app.use(express.static("./public"));
app.use(bodyParser.urlencoded({ extended: false }));
//咱们现在在写接口
app.post("/insert",function(req,res){
    db.insert("worker",{
        name:req.body.name,
        age:req.body.age
    },function(err,results){
        if(err){
            res.json(-1);
        }else{
            res.json(1);
        }
    });
})
//获得工人信息,根据姓名来查
app.get("/getworker",function(req,res){
    console.log(req.query.name);
    db.find("worker",{"name":req.query.name},function(err,result){
        if(err){
            res.json(-1);
        }else{
            res.json(result);
        }
    })
});
//删除接口
app.get("/delete",function(req,res){
    db.delete("worker",{"_id":mongodb.ObjectID(req.query.id)},function(err,result){
        if(err){
            res.json(-1);//失败
        }else{
            res.json(1);//成功
        }
    })
});
//修改接口
app.post("/update",function(req,res){
    db.update("worker",{"_id":mongodb.ObjectID(req.body.workerid)},{
        $set:{
            name:req.body.name,
            age:req.body.age
        }
    },function(err,results){
        if(err){
            res.json(-1);//失败
        }else{
            res.json(1);//成功
        }
    })
})
app.get("/edit.html",function(req,res){
    //res.send(req.query.id);
    db.find("worker",{"_id":mongodb.ObjectID(req.query.id)},function(err,results){
        res.render("edit",results[0]);
    });

})
app.get("/page",function(req,res){
    db.count("worker",{},function(count){
        //console.log(count);
        db.find("worker",{},function(err,results){
            var obj={
                pageSum:Math.ceil(count/2),
                content:results
            }
            res.json(obj);
        },{
            sort:{"age":1},
            skip:(req.query.pagenum-1)*2,
            limit:2
        })
    });

})
app.listen(80);