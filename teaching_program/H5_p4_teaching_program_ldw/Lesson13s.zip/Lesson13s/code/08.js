/**
 * Created by tydte on 2017/7/22.
 */
    var express=require("express");
var test=require("./model/db.js");
var app=express();
app.get("/",function(req,res){
    test.find("worker",{"name":"东方88"},function(err,results){
        res.json(results);
    })
});
app.listen(80);
