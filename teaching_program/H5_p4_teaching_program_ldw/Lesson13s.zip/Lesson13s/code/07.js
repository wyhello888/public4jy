/**
 * Created by tydte on 2017/7/22.
 */
var express=require("express");
var mongodb=require("mongodb");
var MongoClient=mongodb.MongoClient;
var app=express();
app.get("/",function(req,res){
    var url="mongodb://127.0.0.1:27017/company";
    MongoClient.connect(url,function(err,db){
        if(err){
            console.log("连接数据库失败");
            return;
        }
        console.log("连接数据库成功");
        var s=db.collection("worker").find({"name":"东方100"});
        console.log(typeof  s);

        var arr=[];
        s.each(function(err,results){
            console.log(results);
            if(results){//当results不为空的时候
                arr.push(results);
            }else{
                res.json(arr);
            }
        });
        //db.collection("worker").find().toArray(function(err,results){
        //    //console.log(results);
        //    res.json(results);
        //})
    })
    //res.send("");

});
app.listen(80);