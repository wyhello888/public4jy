/**
 * Created by tydte on 2017/7/22.
 */
//var test=null;//false
//if(test){
//    console.log(1);
//}else{
//    console.log(2);
//}
//var test=0;//false
//if(test){
//    console.log(1);
//}else{
//    console.log(2);
//}
//var test="";//false
//if(test){
//    console.log(1);
//}else{
//    console.log(2);
//}
//function test(callback){
//    function a(){
//       callback(13);
//    }
//    a();
//}
////console.log(test());
//test(function(num){
//    console.log(num)
//})
console.log(Math.ceil(10/3));