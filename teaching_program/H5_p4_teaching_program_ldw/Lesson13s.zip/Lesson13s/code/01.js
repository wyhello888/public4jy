/**
 * Created by tydte on 2017/7/22.
 */
var express=require("express");
var mongodb=require("mongodb");
//委托
var MongoClient=mongodb.MongoClient;
var app=express();
app.get("/",function(req,res){
    //写的数据库不存在没关系
    var url="mongodb://127.0.0.1:27017/company";//不是咱们网页地址，这个是连接数据库的地址
    MongoClient.connect(url,function(err,db){
        if(err){
            console.log("数据库连接失败");
            return;
        }
        console.log("数据库连接成功");
        for(var i=0;i<10000;i++){
            db.collection("worker").insertOne({
                "name":"李东方",
                "age":i,
                "worker":"保安大叔",
                "money":0.5,
                "hobby":["男","女","举重","乒乓球","短路"]
            },function(err,data){
                if(err){
                    console.log("插入数据失败");
                    return;
                }
                //console.log(data.result.ok);
                console.log(data);
                console.log("插入数据成功");
            })
        }

    })
    res.send("欢迎来到英雄联盟！");
})
app.listen(80);