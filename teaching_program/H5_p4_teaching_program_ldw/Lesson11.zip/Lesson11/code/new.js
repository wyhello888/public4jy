/**
 * Created by tydte on 2017/7/26.
 */
var express=require("express");
var mongodb=require("mongodb");
var db=require("./model/db.js");
var body_parser=require("body-parser");
var app=express();
app.use(body_parser.urlencoded({ extended: false }))
app.use(express.static("./public"));
app.post("/editNew",function(req,res){
    db.update("newlist",{"_id":mongodb.ObjectID(req.body.id)},{
        $set:{
            title:req.body.title,
            order:req.body.order
        }
    },function(err,results){
        if(err){
            res.json({
                msgId:-1,
                msgStr:"修改失败"
            })
        }
        else{
            res.json({
                msgId:1,
                msgStr:"修改成功"
            })
        }
    })
})
//添加的接口
app.post("/addNew",function(req,res){
    db.insert("newlist",{
        title:req.body.title,
        order:req.body.order
    },function(err,results){
        if(err){
            res.json({
                msgId:-1,
                msgStr:"插入失败"
            })
        }
        else{
            res.json({
                msgId:1,
                msgStr:"插入成功"
            })
        }
    })
    //res.json(req.body.title);//
});
app.get("/getNewById",function(req,res){
    db.findOne("newlist",{"_id":mongodb.ObjectID(req.query.id)},function(err,results){
        if(err){
            res.json({
                msgId:-1,
                msgStr:"网络连接错误"
            })
            return;
        }
        res.json({
            msgId:1,
            msgStr:"成功",
            results:results
        })
    })
})
app.get("/getNew",function(req,res){
    db.find("newlist",{},function(err,results){
        if(err){
            res.json({
                msgId:-1,
                msgStr:"查找内容失败",
                results:{}
            })
            return;
        }
        res.json({
            msgId:1,
            msgStr:"查找成功",
            results:results
        })
    })
})
















//app.get("/getNew",function(req,res){
//    //res.header("Access-Control-Allow-Origin", "*");
//    //res.header("Access-Control-Allow-Headers", "X-Requested-With");
//    //res.header("Access-Control-Allow-Methods","PUT,POST,GET,DELETE,OPTIONS");
//    //res.header("X-Powered-By",' 3.2.1')
//    //res.header("Content-Type", "application/json;charset=utf-8");
//    res.json({"name":"laotie"});
//    //res.send(req.query.callback+'({"name":"laowang"})')
//})
app.listen(80);