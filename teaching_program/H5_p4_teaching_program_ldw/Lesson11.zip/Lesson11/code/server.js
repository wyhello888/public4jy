/**
 * Created by tydte on 2017/7/24.
 */
var express=require("express");
var mongodb=require("mongodb");
var fs=require("fs");
var db=require("./model/db.js");
var app=express();
var formidable=require("formidable");
app.use(express.static("./public"));
var imgUrl='public/upload/img/';
//服务器端给咱们提供的接口
app.get("/getPicList",function(req,res){
    db.find("picList",{},function(err,results){
        res.json({
            picUrl:"/upload/img/",
            results:results
        });
    })
})
app.post("/upPic",function(req,res){
    var form = new formidable.IncomingForm();   //创建上传表单
    form.encoding = 'utf-8';        //设置编辑
    form.uploadDir = imgUrl;     //设置上传目录
    form.keepExtensions = true;     //保留后缀
    form.maxFieldsSize = 2 * 1024 * 1024;   //文件大小
    //fields:字段域
    //files:文件
    form.parse(req,function(err, fields, files){
        var extName="";
        //验证图片类型的
        switch (files.picUpLoad.type) {
            case 'image/pjpeg':
                extName = 'jpg';
                break;
            case 'image/jpeg':
                extName = 'jpg';
                break;
            case 'image/png':
                extName = 'png';
                break;
            case 'image/x-png':
                extName = 'png';
                break;
        }
        if(extName.length==0){//
            res.json({
                state:-2,
                msg:"上传图片错误"
            });//上传图片错误
        }else{
            console.log(13);
            var newfile=Math.random()+"."+extName;
            fs.renameSync(files.picUpLoad.path,imgUrl+newfile);
            //添加数据
            db.insert("picList",{
                picName:fields.picName,
                picUrl:newfile
            },function(err,results){
                if(err){
                    res.json({
                        state:-1,
                        msg:"网络连接错误"
                    });
                }else{
                    res.json({
                        state:1,
                        msg:"上传图片成功"
                    })
                }
            })
        }


    });

});
app.get("/get_ById",function(req,res){
    db.findOne("picList",{"_id":mongodb.ObjectID(req.query.id)},function(err,results){
        res.json(results);
    })
});
app.post("/editPic",function(req,res){

    var form = new formidable.IncomingForm();   //创建上传表单
    form.encoding = 'utf-8';        //设置编辑
    form.uploadDir = imgUrl;     //设置上传目录
    form.keepExtensions = true;     //保留后缀
    form.maxFieldsSize = 2 * 1024 * 1024;   //文件大小
    //fields:字段域
    //files:文件
    form.parse(req,function(err, fields, files){
        console.log(files);

        var extName="";
        console.log(files.picUpLoad.type);
        console.log(1);
        //验证图片类型的
        switch (files.picUpLoad.type) {
            case 'image/pjpeg':
                extName = 'jpg';
                break;
            case 'image/jpeg':
                extName = 'jpg';
                break;
            case 'image/png':
                extName = 'png';
                break;
            case 'image/x-png':
                extName = 'png';
                break;
        }
        if(extName.length==0){//
            res.json({
                state:-2,
                msg:"上传图片错误"
            });//上传图片错误
        }else{
            console.log(13);
            var newfile=Math.random()+"."+extName;
            fs.renameSync(files.picUpLoad.path,imgUrl+newfile);
            //添加数据
            db.update("picList",{"_id":mongodb.ObjectID(fields.id)},
                {$set:{ picName:fields.picName,picUrl:newfile}},function(err,results){
                if(err){
                    res.json({
                        state:-1,
                        msg:"网络连接错误"
                    });
                }else{
                    res.json({
                        state:1,
                        msg:"上传图片成功"
                    })
                }
            })
        }


    });

});
app.listen(80);