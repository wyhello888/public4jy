/**
 * Created by tydte on 2017/7/24.
 */
var express=require("express");
var app=express();
app.use(express.static("./public"));
app.get("/",function(req,res){
    res.send("开始了");
})
app.listen(80);