/**
 * Created by tydte on 2017/7/17.
 */
var gulp=require("gulp");//将包引入进来，咱们就可以用gulp里面的接口了
var browser=require("browser-sync");
var sass=require("gulp-sass");
var uglify=require("gulp-uglify");
var obj={
    html:"src/**/*.html",
    sass:"src/sass/**/*.scss",
    js:"src/js/**/*.js"
}
gulp.task("re",function(){
    console.log("我是第一个任务");
});
gulp.task("re2",function(){
    console.log("我是第二个任务");
});
gulp.task("html",function(){//创建一个任务，任务的名字叫做html。该任务是将指定的HTML移到指定的目录下
    console.log("生成页面");
    return gulp.src(obj.html)
        .pipe(gulp.dest("dist"));
});
gulp.task("sass",function(){//编译sass
    return gulp.src("src/sass/**/*.scss")
        .pipe(sass({
            outputStyle:"compressed"
        }))
        .pipe(gulp.dest("dist/css"));
})
gulp.task("browser",function(){//自动打开一个dist下面的页面。
    return browser({
        server:{
            baseDir:"dist"
        }
    });
});
gulp.task("uglify",function(){
    return gulp.src("src/js/**/*.js")
        .pipe(uglify())
        .pipe(gulp.dest("dist/js"));
});
gulp.task("default",["re","re2","sass","uglify","html","browser"],function(){//默认任务---在我执行gulp命令时不写任务名默认选择该任务。
    console.log("我是一个默认任务");
    gulp.watch("src/js/**/*.js",["uglify"]);
    gulp.watch("src/sass/**/*.scss",["sass"]);
    gulp.watch(obj.html,["html"]);//监听我的项目中html文件一旦发生变化，就会执行名字为html的任务
    gulp.watch(obj.html,browser.reload);//只要页面发生变化就实现刷新
})