/**
 * Created by tydte on 2017/7/17.
 */
function test(){
    console.log(12);
}

//静态就是不需要实例化就称为静态。
//静态属性  静态方法（行为）
//var obj={
//    name:"laowang",//静态的属性
//    run:function(){//静态行为（方法）
//
//    }
//}
//
//function Box(){
//    this.name="laotie";//动态属性
//    this.age=12;//动态属性
//    this.run=function(){
//        console.log(12);
//    }
//}
//var obj1=new Box();
//console.log(obj1.name);//动态


function Box(){
    this.name="laotie"
}
Box.prototype.age=12;//静态
var obj=new Box();
